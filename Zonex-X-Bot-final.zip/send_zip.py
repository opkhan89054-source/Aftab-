"""Send a clean copy of this project to a Telegram admin.

Usage:
    python send_zip.py

The bot token is requested privately in the terminal and is never written
to disk or included in the generated ZIP.
"""

from __future__ import annotations

import getpass
import io
import mimetypes
import os
import sys
import urllib.parse
import urllib.request
import uuid
import zipfile
from pathlib import Path


PROJECT_DIR = Path(__file__).resolve().parent
DEFAULT_OUTPUT = PROJECT_DIR.parent / "Zonex-X-Bot-project.zip"
EXCLUDED_PARTS = {
    ".env",
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".venv",
    "venv",
}
EXCLUDED_SUFFIXES = {".db", ".log", ".pyc"}


def make_clean_zip(output_path: Path) -> Path:
    output_path.unlink(missing_ok=True)
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in PROJECT_DIR.rglob("*"):
            if not path.is_file():
                continue
            relative = path.relative_to(PROJECT_DIR)
            if any(part in EXCLUDED_PARTS for part in relative.parts):
                continue
            if path.name.endswith(tuple(EXCLUDED_SUFFIXES)):
                continue
            archive_name = Path("zonex-x-bot") / relative
            archive.write(path, archive_name.as_posix())
    return output_path


def send_document(token: str, admin_id: str, archive_path: Path) -> str:
    boundary = uuid.uuid4().hex
    body = io.BytesIO()

    def write_text(name: str, value: str) -> None:
        body.write(f"--{boundary}\r\n".encode())
        body.write(f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode())
        body.write(value.encode())
        body.write(b"\r\n")

    write_text("chat_id", admin_id)
    body.write(f"--{boundary}\r\n".encode())
    body.write(
        (
            'Content-Disposition: form-data; name="document"; '
            f'filename="{archive_path.name}"\r\n'
            f"Content-Type: {mimetypes.guess_type(archive_path.name)[0] or 'application/zip'}\r\n\r\n"
        ).encode()
    )
    body.write(archive_path.read_bytes())
    body.write(f"\r\n--{boundary}--\r\n".encode())

    request = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/sendDocument",
        data=body.getvalue(),
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        result = response.read().decode("utf-8")
    if '"ok":true' not in result.replace(" ", ""):
        raise RuntimeError(f"Telegram rejected the upload: {result}")
    return result


def main() -> int:
    print("Zonex X Bot ZIP sender")
    print("----------------------")
    token = getpass.getpass("Bot token (hidden): ").strip()
    admin_id = input("Admin Telegram ID: ").strip()
    if not token or not admin_id.lstrip("-").isdigit():
        print("Valid bot token and numeric Admin Telegram ID are required.")
        return 2

    output_text = input(f"ZIP path [{DEFAULT_OUTPUT}]: ").strip()
    output_path = Path(output_text).expanduser() if output_text else DEFAULT_OUTPUT
    archive_path = make_clean_zip(output_path)
    print(f"Created: {archive_path}")
    try:
        send_document(token, admin_id, archive_path)
    except Exception as exc:
        print(f"Upload failed: {exc}")
        return 1
    print("ZIP sent successfully to the Admin Telegram ID.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())